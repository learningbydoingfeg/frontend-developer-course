// verify check path is directory
// verify if Git returns 'fatal not a Git repository'
// verify if Git returns 'On branch'
